	<div id="formulario">
		<h1>Contato</h1>
		Cadastre-se e receba ofertas exclusivas.
		<form>
			<label>Nome completo</label><br>
			<input type="text" name=""><br/>
			<label>E-mail</label><br/>
			<input type="text" name=""><br/>
			<label>Assunto</label><br/>
			<input type="text" name=""><br/>
			<label>Mensagem</label><br/>
			<textarea>
				
			</textarea><br>
			<button>Enviar</button>
		</form>
		<img src='images/doces.jpg'>
	</div>
	
	